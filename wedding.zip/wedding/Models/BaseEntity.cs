namespace wedding.Models
{
    public abstract class BaseEntity {}
}