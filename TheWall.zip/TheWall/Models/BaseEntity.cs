namespace TheWall.Models
{
    public abstract class BaseEntity {}
}