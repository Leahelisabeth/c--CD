namespace ConsoleApplication{
    //dextr = 175; method steal()= attack(),health+=10; get_away()=hea;th-=15;
    public class Ninja: Human 
    {
        public int dexterity{get; set;}
        public Ninja():base(Human.name){
            dexterity = 175;
        }
        public void Steal(Human enemy){
            Attack(enemy);
            health+=10;
        }
        public void Get_away(){
            health-= 15;
        }
    }
}