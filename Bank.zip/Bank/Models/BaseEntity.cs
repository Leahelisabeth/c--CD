namespace Bank.Models
{
    public abstract class BaseEntity {}
}