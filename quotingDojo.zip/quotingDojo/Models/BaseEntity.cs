namespace quotingDojo.Models
{
    public abstract class BaseEntity {}
}