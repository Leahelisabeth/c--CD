using quotingDojo.Models;

namespace quotingDojo.Factories
{
    public interface IFactory<T> where T : BaseEntity {}
}